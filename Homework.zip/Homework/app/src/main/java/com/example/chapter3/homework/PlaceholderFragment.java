package com.example.chapter3.homework;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

import java.util.ArrayList;
import java.util.List;


public class PlaceholderFragment extends Fragment{

    private String[] data={"Zhang","Zhou","Wu","Wang","Liu","Yi","Li","Lu","HuangPu","OuYang","Ma","Huang","Kai"};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // TODO ex3-3: 修改 fragment_placeholder，添加 loading 控件和列表视图控件

        return inflater.inflate(R.layout.fragment_placeholder, container, false);

    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        getView().postDelayed(new Runnable() {
            @Override
            public void run()

            {

                // 这里会在 5s 后执行
                // TODO ex3-4：实现动画，将 lottie 控件淡出，列表数据淡入

                LottieAnimationView animationView;
                animationView = getView().findViewById(R.id.loading);
                animationView.animate().setDuration(500).alpha(0f);
                TextView mtext1;
                mtext1 = getView().findViewById(R.id.mtext1);
                mtext1.setText("Yang");
                mtext1.setAlpha(0f);
                mtext1.animate().setDuration(500).alpha(1f);

                TextView mtext2;
                mtext2 = getView().findViewById(R.id.mtext2);
                mtext2.setText("Lu");
                mtext2.setAlpha(0f);
                mtext2.animate().setDuration(500).alpha(1f);
                TextView mtext3;
                mtext3 = getView().findViewById(R.id.mtext3);
                mtext3.setText("Zhang");
                mtext3.setAlpha(0f);
                mtext3.animate().setDuration(500).alpha(1f);


            }
        }, 5000);

    }

}
