package com.bytedance.androidcamp.network.dou;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;

import java.util.Random;

public class VideoActivity extends AppCompatActivity {
    private VideoView videoView;
    private ImageView mBegin;
    private boolean iscollected = false;
    private ImageView zan;
    private TextView zannum;
    private String mUrl;

    public static void launch(Activity activity, String url) {
        Intent intent = new Intent(activity, VideoActivity.class);
        intent.putExtra("url", url);
        activity.startActivity(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        String url = getIntent().getStringExtra("url");
        mUrl = url;
        videoView = findViewById(R.id.video_container);
        mBegin = findViewById(R.id.mStart);
        zannum = findViewById(R.id.zannum);
        if(!isCollected("dianzan"))
            refreshZanNum(getZanNum());
        zannum.setText(""+getZanNum());
        zan = findViewById(R.id.dianzan);
        final ProgressBar progressBar = findViewById(R.id.progress_bar);
        videoView.setVideoURI(Uri.parse(url));
        videoView.requestFocus();
        videoView.start();
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                progressBar.setVisibility(View.GONE);
            }
        });

        progressBar.setVisibility(View.VISIBLE);
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                videoView.start();
            }
        });

        mBegin.setAlpha(0f);

        setTouchListenter();
        final Button collect = findViewById(R.id.mCollect);
        if(!isCollected("collect"))
            collect.setAlpha(0.7f);
        collect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isCollected("collect")) {
                    collect.animate().setDuration(200).scaleX(5f).scaleY(5f);
                    collect.animate().setDuration(200).scaleX(0.5f).scaleY(0.5f).alpha(1f);
                    collect.animate().setDuration(200).scaleX(1).scaleY(1f);
                    addToSharePreference("collect");
                }
            }

        });


    }


    public void addToSharePreference(String name){
        SharedPreferences pref = getSharedPreferences(name,MODE_PRIVATE);
        int currentnum = pref.getInt("total",0);
        currentnum++;
        SharedPreferences.Editor editor = getSharedPreferences(name,MODE_PRIVATE).edit();
        editor.putInt("total",currentnum);
        editor.putString(name+currentnum, mUrl);
        editor.commit();
    }
    public boolean isCollected(String name){
        SharedPreferences pref = getSharedPreferences(name,MODE_PRIVATE);
        int currentnum = pref.getInt("total",0);
        for(int i=1; i<=currentnum; i++){
            String getUrl = pref.getString(name+i, "");
            if(getUrl.equals(mUrl))
                return true;
        }
        return false;
    }
    public void refreshZanNum(int num){
        SharedPreferences pref = getSharedPreferences("dianzannum",MODE_PRIVATE);
        int currentnum = pref.getInt("total",0);
        currentnum++;
        SharedPreferences.Editor editor = getSharedPreferences("dianzannum",MODE_PRIVATE).edit();
        editor.putInt("total",currentnum);
        editor.putInt(mUrl, num);
        editor.commit();
    }
    public int getZanNum(){
        SharedPreferences pref = getSharedPreferences("dianzannum",MODE_PRIVATE);
        int result =  pref.getInt(mUrl,0);
        if(result == 0){
            Random random = new Random();
            int max = 9000;
            int min = 0;
            return random.nextInt(max)%(max-min+1) + min;
        }
        else
            return result;
    }
    public void deleteZan(){
        SharedPreferences.Editor editor = getSharedPreferences("dianzan",MODE_PRIVATE).edit();
        SharedPreferences pref = getSharedPreferences("dianzan",MODE_PRIVATE);
        int currentnum = pref.getInt("total",0);
        int i;
        for(i=1; i<=currentnum; i++){
            String getUrl = pref.getString("dianzan"+i, "");
            if(getUrl.equals(mUrl))
                break;
        }
        editor.remove("dianzan"+i);
        editor.commit();
    }

    public void setTouchListenter()
    {
        //noinspection AndroidLintClickableViewAccessibility
        videoView.setOnTouchListener(new View.OnTouchListener()
        {
            int	count = 0;
            boolean	isLongClick	= false;

            @Override
            public boolean onTouch(final View view, final MotionEvent event)
            {

                if(MotionEvent.ACTION_DOWN == event.getAction())
                {
                    if(count == 0)
                    { // 每次事件（双击、单击、长按）只有第一次点击，才开启线程统计600ms内点击字数
                        new Handler().postDelayed(new Runnable()
                        {
                            @Override
                            public void run()
                            {

                                if(count == 2)
                                { // 双击
                                    if(!isCollected("dianzan")) {
                                        showzan(event);
                                        addToSharePreference("dianzan");
                                    }
                                    else{
                                        int tnum = getZanNum();
                                        tnum--;
                                        refreshZanNum(tnum);
                                        deleteZan();
                                        zannum.setText(""+getZanNum());

                                    }

                                }else if(count == 1)
                                { // 单击
                                    if(videoView.isPlaying()) {
                                        videoView.pause();
                                        mBegin.setVisibility(View.VISIBLE);
                                        mBegin.setScaleY(2.5f);
                                        mBegin.setScaleX(2.5f);
                                        mBegin.animate().setDuration(200).alpha(0.4f).scaleY(1f).scaleX(1f);

                                    }
                                    else {
                                        videoView.start();
                                        mBegin.animate().setDuration(100).alpha(0f);

                                    }
                                }else if(count == 0)
                                {
                                    isLongClick = true;// 设置标志位，长按
                                }
                                count = 0;// 判断结束，将count置为0
                            }
                        }, 600);
                    }
                    return true; // 此处若返回 false 则 action_up事件不会触发

                }

                if(MotionEvent.ACTION_UP == event.getAction())
                {
                    if(isLongClick)
                    {// 长按
                        isLongClick = false;
                        return true;
                    }
                    count++;
                }
                return true;
            }
        });

    }
    public static ObjectAnimator scale(View view, String propertyName, float from, float to, long time, long delayTime) {
        ObjectAnimator translation = ObjectAnimator.ofFloat(view
                , propertyName
                , from, to);
        translation.setInterpolator(new LinearInterpolator());
        translation.setStartDelay(delayTime);
        translation.setDuration(time);
        return translation;
    }
    public static ObjectAnimator translationX(View view, float from, float to, long time, long delayTime) {
        ObjectAnimator translation = ObjectAnimator.ofFloat(view
                , "translationX"
                , from, to);
        translation.setInterpolator(new LinearInterpolator());
        translation.setStartDelay(delayTime);
        translation.setDuration(time);
        return translation;
    }
    public static ObjectAnimator translationY(View view, float from, float to, long time, long delayTime) {
        ObjectAnimator translation = ObjectAnimator.ofFloat(view
                , "translationY"
                , from, to);
        translation.setInterpolator(new LinearInterpolator());
        translation.setStartDelay(delayTime);
        translation.setDuration(time);
        return translation;
    }
    public static ObjectAnimator alpha(View view, float from, float to, long time, long delayTime) {
        ObjectAnimator translation = ObjectAnimator.ofFloat(view
                , "alpha"
                , from, to);
        translation.setInterpolator(new LinearInterpolator());
        translation.setStartDelay(delayTime);
        translation.setDuration(time);
        return translation;
    }
    public static ObjectAnimator rotation(View view, long time, long delayTime, float... values) {
        ObjectAnimator rotation = ObjectAnimator.ofFloat(view, "rotation", values);
        rotation.setDuration(time);
        rotation.setStartDelay(delayTime);
        rotation.setInterpolator(new TimeInterpolator() {
            @Override
            public float getInterpolation(float input) {
                return input;
            }
        });
        return rotation;
    }
    public void showzan(MotionEvent event){
        float[] num = {-30, -20, 0, 20, 30};
        final ImageView imageView = new ImageView(VideoActivity.this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(500, 500);
        params.leftMargin = (int) event.getX() - 150;
        params.topMargin = (int) event.getY() - 300;
        Log.d("VideoActivity", "run: "+ params.leftMargin);
        imageView.setImageResource(R.drawable.dianzantu);
        imageView.setLayoutParams(params);
        final RelativeLayout relative = findViewById(R.id.relative);
        relative.addView(imageView);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(scale(imageView, "scaleX", 2f, 0.9f, 100, 0))
                .with(scale(imageView, "scaleY", 2f, 0.9f, 100, 0))
                .with(rotation(imageView, 0, 0, num[new Random().nextInt(4)]))
                .with(alpha(imageView, 0, 1, 100, 0))
                .with(scale(imageView, "scaleX", 0.9f, 1, 50, 150))
                .with(scale(imageView, "scaleY", 0.9f, 1, 50, 150))
                .with(translationY(imageView, 0, -600, 800, 400))
                .with(alpha(imageView, 1, 0, 300, 400))
                .with(scale(imageView, "scaleX", 1, 3f, 700, 400))
                .with(scale(imageView, "scaleY", 1, 3f, 700, 400));
        animatorSet.start();
        animatorSet.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                relative.removeViewInLayout(imageView);
            }
        });
        int tnum = getZanNum();
        tnum = tnum+1;
        zannum.setText(""+tnum);
        refreshZanNum(tnum);
    }



}
