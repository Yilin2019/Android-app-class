package com.bytedance.androidcamp.network.dou;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.bytedance.androidcamp.network.dou.api.IMiniDouyinService;
import com.bytedance.androidcamp.network.dou.model.GetVideoResponse;
import com.bytedance.androidcamp.network.dou.model.PostVideoResponse;
import com.bytedance.androidcamp.network.dou.model.Video;
import com.bytedance.androidcamp.network.dou.model.videoList;
import com.bytedance.androidcamp.network.dou.util.Utils;
import com.bytedance.androidcamp.network.lib.util.ImageHelper;
import com.bytedance.androidcamp.network.dou.util.ResourceUtils;
import com.iceteck.silicompressorr.SiliCompressor;

import java.io.File;
import java.io.FileInputStream;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {


    private RecyclerView mRv;
    private List<Video> mVideos = new ArrayList<>();

    private RecyclerView.LayoutManager mLayoutManager;
    private RecyclerView.RecycledViewPool pool=new RecyclerView.RecycledViewPool();
    private SwipeRefreshLayout mSwipeRefreshWidget;


    private Retrofit retrofit;
    private IMiniDouyinService miniDouyinService;
    private final static int REQUEST_RECORD_CAMERA = 1;
    private String[] permissions = new String[] {
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_EXTERNAL_STORAGE
    };


    private IMiniDouyinService getDouyinService(){
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(IMiniDouyinService.BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        if (miniDouyinService == null) {
            miniDouyinService = retrofit.create(IMiniDouyinService.class);
        }
        return miniDouyinService;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initRecyclerView();

        loginOrNot();
        Log.d("MainActivity", "onCreate: ??????");
        bindActivity(R.id.favorites, FavoriteActivity.class);
        bindActivity(R.id.about_me, UserActivity.class);
        refresh();
        Log.d("MainActivity", "onCreate: ??????");
        mSwipeRefreshWidget = findViewById(R.id.swipe_refresh_widget);
        mSwipeRefreshWidget.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refresh();
                mSwipeRefreshWidget.setRefreshing(false);
            }
        });
        Log.d("MainActivity", "onCreate: ??????");
        Button mPost = (Button) findViewById(R.id.post);
        mPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Utils.isPermissionsReady(MainActivity.this, permissions)) {
                    startActivity(new Intent(MainActivity.this, CustomCameraActivity.class));
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                } else {
                    Utils.reuqestPermissions(MainActivity.this, permissions, REQUEST_RECORD_CAMERA);
                }
            }
        });
        Log.d("MainActivity", "onCreate: ??????");

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @Nullable String[] permissions, @Nullable int[] grantResults){
        switch(requestCode){
            case REQUEST_RECORD_CAMERA:
                if(Utils.isPermissionsReady(this, permissions)){
                    startActivity(new Intent(MainActivity.this, CustomCameraActivity.class));
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                }
                else{
                    Toast.makeText(MainActivity.this, "Fail To Open Camera", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }



    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageView img;
        public TextView studentId;
        public TextView userName;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.img);
            studentId=itemView.findViewById(R.id.studentId);
            userName=itemView.findViewById(R.id.userName);
        }

        public void bind(final Activity activity, final Video video) {
            studentId.setText(video.getStudentId());
            userName.setText(video.getUserName());
            ImageHelper.displayWebImage(video.getImageUrl(), img);
            img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    VideoActivity.launch(activity, video.getVideoUrl());
                }
            });


        }
    }

    private void initRecyclerView() {
        Log.d("intRV", "start init RV");
        mRv = findViewById(R.id.rv);
        mLayoutManager=new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        mRv.setLayoutManager(mLayoutManager);
        mRv.setItemViewCacheSize(100);
        mRv.setRecycledViewPool(pool);


        mRv.setAdapter(new RecyclerView.Adapter<MyViewHolder>() {
            @NonNull
            @Override
            public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                return new MyViewHolder(
                        LayoutInflater.from(MainActivity.this)
                                .inflate(R.layout.video_item_view, viewGroup, false));
            }

            @Override
            public void onBindViewHolder(@NonNull MyViewHolder viewHolder, int i) {
                final Video video = mVideos.get(i);
                viewHolder.bind(MainActivity.this, video);

            }

            @Override
            public int getItemCount() {
                return mVideos.size();
            }
        });
    }

    public void fetchFeed(View view) {

        // TODO 10: get videos & update recycler list
        Call<videoList> call=getDouyinService().getVideos();
        call.enqueue(new Callback<videoList>() {
            @Override
            public void onResponse(Call<videoList> call, Response<videoList> response) {
                if (response.body() != null && response.body().getVideoList() != null) {
                    mVideos.clear();
                    mVideos.addAll(response.body().getVideoList());

                    mRv.setItemAnimator(null);
                    mRv.getAdapter().notifyDataSetChanged();
                }
                else
                    Log.d("oR", " onRespond body null");
            }
            @Override
            public void onFailure(Call<videoList> call, Throwable throwable) {

            }
        });


        Toast.makeText(this, "TODO 10: get videos & update recycler list", Toast.LENGTH_SHORT).show();
    }
    void refresh(){
        Call<videoList> call=getDouyinService().getVideos();
        call.enqueue(new Callback<videoList>() {
            @Override
            public void onResponse(Call<videoList> call, Response<videoList> response) {
                Log.d("oR", " onRespond");
                if (response.body() != null && response.body().getVideoList() != null) {
                    mVideos.clear();
                    mVideos.addAll(response.body().getVideoList());
                    mRv.setItemAnimator(null);
                    mRv.getAdapter().notifyDataSetChanged();
                }
                else
                    Log.d("oR", " onRespond body null");

            }
            @Override
            public void onFailure(Call<videoList> call, Throwable throwable) {

            }
        });
    }
    private void bindActivity(final int btnId, final Class<?> activityClass) {
        if(btnId != R.id.post){
            findViewById(btnId).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this, activityClass));
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                }
            });
        }

    }



    private void loginOrNot(){
        SharedPreferences preferences=getSharedPreferences("user_info",Activity.MODE_PRIVATE);
        int loginSituation=preferences.getInt("loginbool", 0);
        Log.d("loginOrNot", ""+loginSituation);
        if(loginSituation==0){
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
        }
    }
}






