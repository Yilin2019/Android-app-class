package com.bytedance.androidcamp.network.dou;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.bytedance.androidcamp.network.dou.api.IMiniDouyinService;
import com.bytedance.androidcamp.network.dou.model.PostVideoResponse;
import com.bytedance.androidcamp.network.dou.util.ResourceUtils;
import com.bytedance.androidcamp.network.dou.util.Utils;
import com.iceteck.silicompressorr.SiliCompressor;

import java.io.File;
import java.io.FileInputStream;
import java.io.StringReader;
import java.net.URISyntaxException;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Past extends AppCompatActivity {
    private Uri imgUri;
    private Uri videoUri;
    private String imgPath;
    private String videoPath;
    private static final long mbToB = 10485760;
    private TextView loading;
    private Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(IMiniDouyinService.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build();
    private IMiniDouyinService miniDouyinService = retrofit.create(IMiniDouyinService.class);
    private String userName,studentId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post);
        SharedPreferences pref = getSharedPreferences("current",MODE_PRIVATE);
        videoPath = pref.getString("video","");
        imgPath = pref.getString("image","");
        File imgFile = new File(imgPath);
        imgUri = FileProvider.getUriForFile(this, "com.bytedance.androidcamp.network.dou", imgFile);
        File videoFile = new File(videoPath);
        videoUri = FileProvider.getUriForFile(this, "com.bytedance.androidcamp.network.dou", videoFile);
        //上传视频
        loading = (TextView)findViewById(R.id.loading);
        Log.d("dddddd", "onCreate: "+videoUri);
        getInfo();
        Log.d("dddddd", "onCreate: "+videoUri);
        past();
        Button back = findViewById(R.id.goback);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Past.this, MainActivity.class));
            }
        });
    }

    public void getInfo(){
        SharedPreferences pref = getSharedPreferences("user_info",MODE_PRIVATE);
        studentId = pref.getString("studentId","");
        userName = pref.getString("studentName","");
    }
    public void past(){
        if (imgUri != null && videoUri != null) {

            if(isTooLarge(imgUri,videoUri)){
                Log.d("www", "past: **"+imgUri);
                loading.setText("Compressing");
                loading.setEnabled(false);
                new Thread(){
                    @Override public void run(){
                        imgUri = mCompressPictures();
                        videoUri = mCompressVDs();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                postVideo();
                            }
                        });
                    }
                }.start();
            }
            else{postVideo();}
        }
    }
    void getPermission(){
        int REQUEST_EXTERNAL_STORAGE = 1;
        String[] PERMISSIONS_STORAGE = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        int permission = ActivityCompat.checkSelfPermission(Past.this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    Past.this,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }
    private Uri mCompressPictures(){

        getPermission();
        String startPath = imgPath;
        Log.d("Past", "run: "+startPath);
        imgPath = SiliCompressor.with(getApplicationContext()).compress(startPath,new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath()),false);
        imgUri = Uri.fromFile(new File(imgPath));
        Log.d("Past", "run:* "+imgPath);

        return imgUri;
    }
    private Uri mCompressVDs(){

        try {
            getPermission();
            String startPath = videoPath;
            videoPath = SiliCompressor.with(getApplicationContext()).compressVideo(startPath, Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath());
            videoUri = Uri.fromFile(new File(videoPath));
            String endPath = videoPath;
            Log.d("Past", "The video address after compress is: "+endPath);
        }catch(URISyntaxException e) {
            e.printStackTrace();
        }
        return videoUri;
    }
    boolean isTooLarge(Uri mSelectedVideo, Uri mSelectedImage){


        long imageSize = 0, videoSize = 0;
        try{
            imageSize = getFileSize(imgPath);
        }catch(Exception e){
            e.getMessage();
            return true;
        }
        try{
            videoSize = getFileSize(videoPath);
        }catch (Exception e){
            e.getMessage();
            return true;
        }
        Log.d("Past", "isTooLarge: "+imageSize+"and"+videoSize);
        if(imageSize + videoSize >= mbToB){
            return true;
        }

        return false;
    }
    long getFileSize(String filePath)throws Exception{
        File file = new File(filePath);
        long size = 0;
        if(file.exists() && !file.isDirectory()){
            FileInputStream fis = null;
            fis = new FileInputStream(file);
            size = fis.available();
        }
        else{
            Toast toast = Toast.makeText(getApplicationContext(), "There is no such file", Toast.LENGTH_SHORT);
            toast.show();
        }
        return size;
    }
    private void postVideo() {
        loading.setText("POSTING...");

        MultipartBody.Part coverImagePart = getMultipartFromUri("cover_image", imgPath);
        MultipartBody.Part videoPart = getMultipartFromUri("video", videoPath);
        Log.d("dddddd", "onCreate:all "+videoPath+imgPath);
        // TODO 9: post video & update buttons
        Call<PostVideoResponse> call = miniDouyinService.postVideo(studentId,userName, coverImagePart, videoPart);
        call.enqueue(new Callback<PostVideoResponse>() {
            @Override
            public void onResponse(Call<PostVideoResponse> call, Response<PostVideoResponse> response) {
                if(response.isSuccessful() && response.body() != null){
                    Toast.makeText(Past.this, "Susscess to post", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<PostVideoResponse> call, Throwable throwable) {
                Toast.makeText(Past.this, "Fail to post", Toast.LENGTH_SHORT).show();
            }
        });


    }
    private MultipartBody.Part getMultipartFromUri(String name, String path) {
        File f = new File(path);
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), f);
        return MultipartBody.Part.createFormData(name, f.getName(), requestFile);
    }

}
