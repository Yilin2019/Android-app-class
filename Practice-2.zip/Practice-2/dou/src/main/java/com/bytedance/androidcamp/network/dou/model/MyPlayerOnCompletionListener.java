package com.bytedance.androidcamp.network.dou.model;

import android.media.MediaPlayer;
import android.widget.Toast;

class MyPlayerOnCompletionListener implements MediaPlayer.OnCompletionListener {

    @Override
    public void onCompletion(MediaPlayer mp) {

    }
}
