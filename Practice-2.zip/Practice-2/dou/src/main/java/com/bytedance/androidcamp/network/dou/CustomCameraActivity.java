package com.bytedance.androidcamp.network.dou;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.ImageFormat;
import android.graphics.Canvas;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.support.annotation.RequiresApi;

import com.bytedance.androidcamp.network.dou.model.CircleButton;
import com.bytedance.androidcamp.network.dou.util.UriUtils;
import com.bytedance.androidcamp.network.dou.util.Utils;
import com.iceteck.silicompressorr.Util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import static com.bytedance.androidcamp.network.dou.util.Utils.MEDIA_TYPE_IMAGE;
import static com.bytedance.androidcamp.network.dou.util.Utils.MEDIA_TYPE_VIDEO;
import static com.bytedance.androidcamp.network.dou.util.Utils.getOutputMediaFile;
import static com.bytedance.androidcamp.network.dou.util.Utils.mGetOutputMediaFile;

public class CustomCameraActivity extends AppCompatActivity {

    private SurfaceView mSurfaceView;
    private Camera mCamera;

    private int CAMERA_TYPE = Camera.CameraInfo.CAMERA_FACING_BACK;

    private boolean isdelay = false;
    private long starttime = 0;
    private short mDelayTime = 5000;
    private int TIME_INTERVAL = 1000;
    private String filePath;
    private boolean isRecording = false;
    private Handler handler;
    private int mNum = 4;


    private int rotationDegree = 0;


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_custom_camera);

        mSurfaceView = findViewById(R.id.img);

        mCamera = getCamera(CAMERA_TYPE);
        final SurfaceView mSurfaceView = findViewById(R.id.img);
        SurfaceHolder surfaceHolder = mSurfaceView.getHolder();
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        surfaceHolder.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder surfaceHolder) {
                try {
                    mCamera.setPreviewDisplay(surfaceHolder);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (mCamera == null) {
                    mCamera = getCamera(CAMERA_TYPE);
                }
                mCamera.startPreview();
            }

            @Override
            public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
                releaseCameraAndPreview();
            }
        });

        CircleButton mCircleButton = (CircleButton) findViewById(R.id.circlebutton);
        Button okButton = findViewById(R.id.okbutton);
        okButton.setVisibility(View.INVISIBLE);
        okButton.setEnabled(false);

        mCircleButton.setOnRecordListener(new CircleButton.OnRecordListener() {
            Button okButton = findViewById(R.id.okbutton);

            @Override
            public void onShortClick() {
                if (isRecording == true) {

                    if (mCamera == null) {
                        mCamera = getCamera(CAMERA_TYPE);
                    }
                    releaseMediaRecorder();
                    isRecording = false;
                    okButton.setVisibility(View.VISIBLE);
                    okButton.setEnabled(true);

                }
            }

            @Override
            public void OnRecordStartClick() {
                if (isRecording == false) {
                    if (mCamera == null) {
                        mCamera = getCamera(CAMERA_TYPE);
                    }
                    Log.d("button", "onShortClick: chenggonglema1");
                    prepareVideoRecorder();
                    isRecording = true;
                    okButton.setVisibility(View.INVISIBLE);
                    okButton.setEnabled(false);

                }
            }

            @Override
            public void OnFinish(int resultCode) {
                if (isRecording == true) {
                    Log.d("button", "onShortClick: chenggonglema2");
                    if (mCamera == null) {
                        mCamera = getCamera(CAMERA_TYPE);
                    }
                    releaseMediaRecorder();
                    isRecording = false;
                    okButton.setVisibility(View.VISIBLE);
                    okButton.setEnabled(true);

                }

            }
        });

        findViewById(R.id.okbutton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mCamera == null)
                    mCamera = getCamera(CAMERA_TYPE);
                startActivity(new Intent(CustomCameraActivity.this, ChooseForPhoto.class));
            }
        });


        findViewById(R.id.change).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                releaseCameraAndPreview();

                if (CAMERA_TYPE == 1) {
                    mCamera = Camera.open(Camera.CameraInfo.CAMERA_FACING_BACK);
                    CAMERA_TYPE = 0;
                } else {
                    mCamera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);
                    CAMERA_TYPE = 1;
                }
                rotationDegree = getCameraDisplayOrientation(CAMERA_TYPE);
                mCamera.setDisplayOrientation(rotationDegree);
                try {
                    mCamera.setPreviewDisplay(mSurfaceView.getHolder());
                    mCamera.startPreview();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });


        findViewById(R.id.go_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mCamera == null) {
                    mCamera = getCamera(CAMERA_TYPE);
                }
                startActivity(new Intent(CustomCameraActivity.this, MainActivity.class));
            }
        });
        final Button startDelay = (Button) findViewById(R.id.delay);
        startDelay.setBackgroundResource(R.drawable.clock);
        SeekBar mTime = findViewById(R.id.timeshow);
        mTime.setVisibility(View.INVISIBLE);

        startDelay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isdelay) {
                    Button okButton = findViewById(R.id.okbutton);
                    okButton.setVisibility(View.INVISIBLE);
                    okButton.setEnabled(false);
                    new CountDownTimer(mDelayTime, TIME_INTERVAL) {
                        @Override
                        public void onTick(long millisUntilFinished) {
                            TextView mTimeText = (TextView) findViewById(R.id.delaytime);
                            mTimeText.setVisibility(View.VISIBLE);
                            mTimeText.setText("" + mNum);
                            mNum--;
                        }

                        @Override
                        public void onFinish() {
                            mNum = 4;
                            TextView mTimeText = (TextView) findViewById(R.id.delaytime);
                            mTimeText.setText("0");
                            mTimeText.setVisibility(View.GONE);
                            prepareVideoRecorder();
                            isdelay = true;
                            startDelay.setBackgroundResource(R.drawable.button_delete_red);
                            starttime = System.currentTimeMillis();
                            SeekBar mTime = findViewById(R.id.timeshow);
                            mTime.setProgress(0);
                            mTime.setVisibility(View.VISIBLE);

                        }
                    }.start();
                } else {
                    isdelay = false;
                    releaseMediaRecorder();
                    Button okButton = findViewById(R.id.okbutton);
                    okButton.setVisibility(View.VISIBLE);
                    okButton.setEnabled(true);
                    startDelay.setBackgroundResource(R.drawable.clock);
                    SeekBar mTime = findViewById(R.id.timeshow);
                    mTime.setVisibility(View.INVISIBLE);
                }

            }
        });

        handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                SeekBar mTime = findViewById(R.id.timeshow);
                int count = (int) ((System.currentTimeMillis() - starttime)) / 1000;
                mTime.setProgress(count * 100 / 10);
                if (count >= 10 && isdelay) {
                    isdelay = false;
                    releaseMediaRecorder();
                    Button okButton = findViewById(R.id.okbutton);
                    okButton.setVisibility(View.VISIBLE);
                    okButton.setEnabled(true);
                    startDelay.setBackgroundResource(R.drawable.clock);
                    mTime.setProgress(0);
                    mTime.setVisibility(View.INVISIBLE);
                }
                handler.postDelayed(this, 1000);
            }
        };
        handler.postDelayed(runnable, 1000);

    }


    public Camera getCamera(int position) {
        CAMERA_TYPE = position;
        if (mCamera != null) {
            releaseCameraAndPreview();
        }
        Camera mCamera = Camera.open(position);
        if (!mCamera.getParameters().isZoomSupported()) {
            Toast.makeText(CustomCameraActivity.this, "Connect to Camera Failed", Toast.LENGTH_SHORT);
        } else {
            Camera.Parameters parameters = mCamera.getParameters();
            parameters.setRecordingHint(true);
            {
                parameters.setPreviewFormat(ImageFormat.NV21);
                mCamera.setPreviewCallback(new Camera.PreviewCallback() {
                    @Override
                    public void onPreviewFrame(byte[] bytes, Camera camera) {
                    }
                });
            }
            mCamera.cancelAutoFocus();
            mCamera.setParameters(parameters);
            mCamera.getParameters().setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            mCamera.autoFocus(new Camera.AutoFocusCallback() {
                @Override
                public void onAutoFocus(boolean success, Camera camera) {

                }
            });
        }

        rotationDegree = getCameraDisplayOrientation(position);
        mCamera.setDisplayOrientation(rotationDegree);
        try {
            mCamera.setPreviewDisplay(mSurfaceView.getHolder());
            mCamera.startPreview();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return mCamera;
    }


    private static final int DEGREE_90 = 90;
    private static final int DEGREE_180 = 180;
    private static final int DEGREE_270 = 270;
    private static final int DEGREE_360 = 360;

    private int getCameraDisplayOrientation(int cameraId) {
        android.hardware.Camera.CameraInfo info =
                new android.hardware.Camera.CameraInfo();
        android.hardware.Camera.getCameraInfo(cameraId, info);
        int rotation = getWindowManager().getDefaultDisplay()
                .getRotation();
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = DEGREE_90;
                break;
            case Surface.ROTATION_180:
                degrees = DEGREE_180;
                break;
            case Surface.ROTATION_270:
                degrees = DEGREE_270;
                break;
            default:
                break;
        }

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % DEGREE_360;
            result = (DEGREE_360 - result) % DEGREE_360;  // compensate the mirror
        } else {  // back-facing
            result = (info.orientation - degrees + DEGREE_360) % DEGREE_360;
        }
        return result;
    }


    private void releaseCameraAndPreview() {
        //todo 释放camera资源
        if (mCamera != null) {
            mCamera.setPreviewCallback(null);
            mCamera.stopPreview();
            mCamera.release();
            mCamera = null;
        }

    }

    Camera.Size size;

    private MediaRecorder mMediaRecorder;

    private boolean prepareVideoRecorder() {
        //todo 准备MediaRecorder
        mCamera = getCamera(CAMERA_TYPE);
        mCamera.unlock();

        mMediaRecorder = new MediaRecorder();
        mMediaRecorder.setCamera(mCamera);

        mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
        mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);

        mMediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_HIGH));
        filePath = getOutputMediaFile(MEDIA_TYPE_VIDEO).toString();
        rememberPath();
        mMediaRecorder.setOutputFile(filePath);

        mMediaRecorder.setPreviewDisplay(mSurfaceView.getHolder().getSurface());
        mMediaRecorder.setOrientationHint(rotationDegree);
        try {
            mMediaRecorder.prepare();
            mMediaRecorder.start();
        } catch (Exception e) {
            releaseMediaRecorder();
            return false;
        }
        Log.d("button", "onShortClick: chenggonglema");

        return true;
    }


    private void releaseMediaRecorder() {
        //todo 释放MediaRecorder
        mMediaRecorder.stop();
        mMediaRecorder.reset();
        mMediaRecorder.release();
        mMediaRecorder = null;
        mCamera.lock();
        Log.d("button", "onShortClick: chenggonglema");
    }

    private void rememberPath() {
        SharedPreferences.Editor editor = getSharedPreferences("current", MODE_PRIVATE).edit();
        editor.putString("video", filePath);
        editor.commit();
    }

    private Camera.PictureCallback mPicture = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            File pictureFile = getOutputMediaFile(MEDIA_TYPE_IMAGE);
            if (pictureFile == null) {
                return;
            }

            try {
                FileOutputStream fos = new FileOutputStream(pictureFile);
                fos.write(data);
                fos.close();
            } catch (IOException e) {
                Log.d("mPicture", "Error accessing file: " + e.getMessage());
            }
        }
    };


}