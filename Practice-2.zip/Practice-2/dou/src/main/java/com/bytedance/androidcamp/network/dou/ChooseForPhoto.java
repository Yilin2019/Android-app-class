package com.bytedance.androidcamp.network.dou;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.VideoView;

import com.bytedance.androidcamp.network.dou.util.UriUtils;
import com.bytedance.androidcamp.network.dou.util.Utils;

import java.io.File;
import java.io.FileOutputStream;

public class ChooseForPhoto extends AppCompatActivity {
    private VideoView videoView;
    private ImageView mPhoto;
    private String imgPath;
    private Uri imgUri;
    private File imgFile;
    private String videoPath;
    private Bitmap bitmap;
    private Button album;
    private Button takeimg;
    private Button publish;
    private static final int LOCAL_CROP = 13;// 本地图库
    private static final int REQUEST_IMAGE_CAPTURE=1;
    String[] permissions = new String[] {
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choosephoto);
        SharedPreferences pref = getSharedPreferences("current",MODE_PRIVATE);
        videoPath = pref.getString("video","");


        File videoImageFile = new File(videoPath);
        MediaMetadataRetriever getImage = new MediaMetadataRetriever();
        getImage.setDataSource(videoPath);
        bitmap = getImage.getFrameAtTime();
        getPicture();
        //图片显示
        mPhoto = (ImageView)findViewById(R.id.previewimage);
        mPhoto.setImageBitmap(bitmap);


        //预览视频
        startVideo();
        album = (Button)findViewById(R.id.photo_album);
        album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                // 启动intent打开本地图库
                startActivityForResult(intent1,LOCAL_CROP);
            }
        });

        takeimg = (Button)findViewById(R.id.take_photo);
        takeimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePicture();
            }
        });
        //监听视频播放完，重复播放
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mPlayer) {
                mPlayer.start();
                mPlayer.setLooping(true);
            }
        });

        publish = (Button)findViewById(R.id.publish);
        publish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ChooseForPhoto.this, Past.class));
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // 获取图库所选图片的uri
        Log.d("ddd", "onActivityResult: **"+resultCode + ""+requestCode);
        if(requestCode == LOCAL_CROP) {
            if (resultCode == RESULT_OK) {
                Uri uri = data.getData();
                imgPath = UriUtils.formatUri(getApplicationContext(), uri);
                rememberimgPath();
                mPhoto.setImageURI(uri);
                startVideo();
            }
        }
        else {
            if(resultCode == RESULT_OK){
                try{
                    rememberimgPath();
                    setPic();
                    startVideo();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }

    }
    private void startVideo(){
        videoView = (VideoView)findViewById(R.id.previewvideo);
        Uri videoUri = Uri.parse(videoPath);
        videoView.setMediaController(new MediaController(this));
        videoView.setVideoURI(videoUri);
        videoView.start();
    }

    private void takePicture() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imgFile = Utils.getOutputMediaFile(Utils.MEDIA_TYPE_IMAGE);
        imgPath = imgFile.getPath();
        if(imgFile != null) {
            imgUri = FileProvider.getUriForFile(this, "com.bytedance.androidcamp.network.dou", imgFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, imgUri);
            startActivityForResult(takePictureIntent,REQUEST_IMAGE_CAPTURE);
        }
    }

    private void setPic()throws Exception {
        //todo 根据imageView裁剪
        int targetW = mPhoto.getWidth();
        int targetH = mPhoto.getHeight();
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imgFile.getAbsolutePath(), bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;
        int scaleFactor = Math.min(photoW / targetW, photoH / targetH);
        //todo 根据缩放比例读取文件，生成Bitmap
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;
        bmOptions.inPurgeable = true;
        Bitmap bmp = BitmapFactory.decodeFile(imgFile.getAbsolutePath(),bmOptions);
        //todo 如果存在预览方向改变，进行图片旋转
        ExifInterface srcExif = new ExifInterface(imgFile.getAbsolutePath());
        Matrix matrix = new Matrix();
        int angle = 0;
        int orientation = srcExif.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);
        switch (orientation){
            case ExifInterface.ORIENTATION_ROTATE_90:
                angle = 90;
                break;
            case ExifInterface.ORIENTATION_ROTATE_180:
                angle = 180;
                break;
            case ExifInterface.ORIENTATION_ROTATE_270:
                angle = 270;
            default:
                break;
        }
        matrix.postRotate(angle);
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(),bmp.getHeight(),matrix, true);
        //todo 如果存在预览方向改变，进行图片旋转

        //todo 显示图片
        mPhoto.setImageBitmap(bmp);
    }

    private void getPicture(){
        File temp = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), "DouPictures");//要保存文件先创建文件夹
        if (!temp.exists()) {
            temp.mkdir();
        }
        imgPath = Environment.getExternalStorageDirectory()+File.separator +"Dou" + ".jpg";

        FileOutputStream fos = null;
        try{
            fos = new FileOutputStream(imgPath);
            bitmap.compress(Bitmap.CompressFormat.JPEG,80, fos);
            rememberimgPath();
            fos.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    private void rememberimgPath(){
        SharedPreferences.Editor editor = getSharedPreferences("current",MODE_PRIVATE).edit();
        editor.putString("image",imgPath);
        editor.commit();
    }
}
