package com.bytedance.androidcamp.network.dou.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetVideoResponse {
    @SerializedName("feeds") private List<Video> mVideo;
    @SerializedName("success") private boolean mSuccess;
    public List<Video> getVideo(){return mVideo;}
    public void setVideo(List<Video> tvideo){mVideo = tvideo;}
    public boolean getSuccess(){return mSuccess;}
    public void setSuccess(boolean tSuccess){mSuccess = tSuccess;}
}
