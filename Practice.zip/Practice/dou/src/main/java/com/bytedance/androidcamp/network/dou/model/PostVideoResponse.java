package com.bytedance.androidcamp.network.dou.model;

import com.google.gson.annotations.SerializedName;

public class PostVideoResponse {
    @SerializedName("result") private result mResult;
    @SerializedName("url") private String mUrl;
    @SerializedName("success") private boolean mSuccess;
    public class result{};
    public result getResult() {return mResult;}
    public void setResult(result tresult){mResult = tresult;}
    public String getUrl(){return mUrl;}
    public void setUrl(String tUrl){mUrl = tUrl;}
    public boolean getSuccess(){return mSuccess;}
    public void setSuccess(boolean tSuccess){mSuccess = tSuccess;}

}
