package com.byted.camp.todolist.beans;

import android.graphics.Color;

/**
 * Created on 2019/1/23.
 *
 * @author xuyingyi@bytedance.com (Yingyi Xu)
 */
public class Priority {

    public static int high = 2;
    public static int medium = 1;
    public static int low = 0;
    public static int highColor = Color.RED;
    public static int mediumColor = Color.GREEN;
    public static int lowColor = Color.WHITE;

    private int priority;
    public Priority (int mPriority) {priority = mPriority;}

    public int getColor () {
        if(priority == low)
            return lowColor;
        else if(priority == medium)
            return mediumColor;
        else
            return highColor;
    }
}
