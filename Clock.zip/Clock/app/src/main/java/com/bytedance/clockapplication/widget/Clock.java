package com.bytedance.clockapplication.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.style.RelativeSizeSpan;
import android.util.AttributeSet;
import android.view.View;

import java.util.Calendar;
import java.util.Locale;

public class Clock extends View {

    private final static String TAG = Clock.class.getSimpleName();

    private static final int FULL_ANGLE = 360;

    private static final int CUSTOM_ALPHA = 140;
    private static final int FULL_ALPHA = 255;

    private static final int DEFAULT_PRIMARY_COLOR = Color.WHITE;
    private static final int DEFAULT_SECONDARY_COLOR = Color.LTGRAY;

    private static final float DEFAULT_DEGREE_STROKE_WIDTH = 0.010f;



    private static final int RIGHT_ANGLE = 90;

    private int mWidth, mCenterX, mCenterY, mRadius;
    private int mHour, mMinute, mSecond, mAmPm;



    /**
     * properties
     */
    private int centerInnerColor;
    private int centerOuterColor;

    private int secondsNeedleColor;
    private int hoursNeedleColor;
    private int minutesNeedleColor;

    private int degreesColor;

    private int hoursValuesColor;

    private int numbersColor;

    private boolean mShowAnalog = true;



    public Clock(Context context) {
        super(context);
        init(context, null);
    }

    public Clock(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public Clock(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        int size;
        int width = getMeasuredWidth();
        int height = getMeasuredHeight();
        int widthWithoutPadding = width - getPaddingLeft() - getPaddingRight();
        int heightWithoutPadding = height - getPaddingTop() - getPaddingBottom();

        size = Math.min(widthWithoutPadding, heightWithoutPadding);
        setMeasuredDimension(size + getPaddingLeft() + getPaddingRight(), size + getPaddingTop() + getPaddingBottom());
    }

    private void init(Context context, AttributeSet attrs) {

        this.centerInnerColor = Color.LTGRAY;
        this.centerOuterColor = DEFAULT_PRIMARY_COLOR;

        this.secondsNeedleColor = DEFAULT_SECONDARY_COLOR;
        this.hoursNeedleColor = DEFAULT_PRIMARY_COLOR;
        this.minutesNeedleColor = DEFAULT_PRIMARY_COLOR;

        this.degreesColor = DEFAULT_PRIMARY_COLOR;

        this.hoursValuesColor = DEFAULT_PRIMARY_COLOR;

        numbersColor = Color.WHITE;
    }

    @Override
    public void onDraw(final Canvas canvas) {
        super.onDraw(canvas);

        mWidth = Math.min(getWidth(), getHeight());

        int halfWidth = mWidth / 2;
        mCenterX = halfWidth;
        mCenterY = halfWidth;
        mRadius = halfWidth;

        if (mShowAnalog) {
            drawDegrees(canvas);
            drawHoursValues(canvas);
            drawNeedles(canvas);
            drawCenter(canvas);
        } else {
            drawNumbers(canvas);
        }
        postInvalidateDelayed(1000);

    }

    private void drawDegrees(Canvas canvas) {

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(mWidth * DEFAULT_DEGREE_STROKE_WIDTH);
        paint.setColor(degreesColor);

        int rPadded = mCenterX - (int) (mWidth * 0.01f);
        int rEnd = mCenterX - (int) (mWidth * 0.05f);

        for (int i = 0; i < FULL_ANGLE; i += 6 /* Step */) {

            if ((i % RIGHT_ANGLE) != 0 && (i % 15) != 0)
                paint.setAlpha(CUSTOM_ALPHA);
            else {
                paint.setAlpha(FULL_ALPHA);
            }

            int startX = (int) (mCenterX + rPadded * Math.cos(Math.toRadians(i)));
            int startY = (int) (mCenterX - rPadded * Math.sin(Math.toRadians(i)));

            int stopX = (int) (mCenterX + rEnd * Math.cos(Math.toRadians(i)));
            int stopY = (int) (mCenterX - rEnd * Math.sin(Math.toRadians(i)));

            canvas.drawLine(startX, startY, stopX, stopY, paint);

        }
    }

    /**
     * @param canvas
     */
    private void drawNumbers(Canvas canvas) {

        TextPaint textPaint = new TextPaint();
        textPaint.setTextSize(mWidth * 0.2f);
        textPaint.setColor(numbersColor);
        textPaint.setColor(numbersColor);
        textPaint.setAntiAlias(true);

        getCurrentTime();

        String time = String.format("%s:%s:%s%s",
                String.format(Locale.getDefault(), "%02d", mHour),
                String.format(Locale.getDefault(), "%02d", mMinute),
                String.format(Locale.getDefault(), "%02d", mSecond),
                mAmPm == Calendar.AM ? "AM" : "PM");

        SpannableStringBuilder spannableString = new SpannableStringBuilder(time);
        spannableString.setSpan(new RelativeSizeSpan(0.3f), spannableString.toString().length() - 2, spannableString.toString().length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); // se superscript percent

        StaticLayout layout = new StaticLayout(spannableString, textPaint, canvas.getWidth(), Layout.Alignment.ALIGN_CENTER, 1, 1, true);
        canvas.translate(mCenterX - layout.getWidth() / 2f, mCenterY - layout.getHeight() / 2f);
        layout.draw(canvas);
    }

    /**
     * Draw Hour Text Values, such as 1 2 3 ...
     *
     * @param canvas
     */
    private void drawHoursValues(Canvas canvas) {
        // Default Color:
        // - hoursValuesColor
        TextPaint hourValuePaint = new TextPaint();
        hourValuePaint.setTextSize(mWidth * 0.08f);
        hourValuePaint.setColor(numbersColor);
        hourValuePaint.setAntiAlias(true);
        hourValuePaint.setStrokeWidth(mWidth * 0.005f);

        Rect rect = new Rect();
        hourValuePaint.getTextBounds("0", 0, "0".length(), rect);
        float w = rect.width();
        float h = rect.height();
        hourValuePaint.getTextBounds("1", 0, "1".length(), rect);
        float w1 = rect.width();

        for (int i = 0; i < FULL_ANGLE; i += 30 ){

            float x, y;
            x = (float) (mCenterX - mWidth*0.045f + 0.73*mRadius * Math.cos(Math.toRadians(i)));
            y = (float) (mCenterY + mWidth*0.026f + 0.73*mRadius * Math.sin(Math.toRadians(i)));


            String num;
            int count = (i / 30 + 3) % 12;

            if(count == 0)
                num = "" + 12;
            else if(count < 10)
                num = "0" + count;
            else
                num = "" + count;

            canvas.drawText(num, x, y, hourValuePaint);
        }

    }

    /**
     * Draw hours, minutes needles
     * Draw progress that indicates hours needle disposition.
     *
     * @param canvas
     */
    private void drawNeedles(final Canvas canvas) {
        // Default Color:
        // - secondsNeedleColor
        // - hoursNeedleColor
        // - minutesNeedleColor
        getCurrentTime();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(degreesColor);

        float secondLength = (float)(0.75 * mRadius);
        float minuteLength = (float)(0.63 * mRadius);
        float hourLength = (float)(0.4 * mRadius);
        float secondPointx, hourPointx, minutePointx,secondPointy, hourPointy, minutePointy;

        secondPointx = (float) (mCenterX + secondLength * Math.cos(Math.toRadians((mSecond * 6 + 270)%360)));
        secondPointy = (float) (mCenterY + secondLength * Math.sin(Math.toRadians((mSecond * 6 + 270)%360)));
        paint.setStrokeWidth(mWidth * 0.005f);
        paint.setAlpha(200);
        canvas.drawLine(mCenterX, mCenterY, secondPointx, secondPointy, paint);

        minutePointx = (float) (mCenterX + minuteLength * Math.cos(Math.toRadians((mMinute * 6 + 270 + 6 * mSecond / 60.0)%360)));
        minutePointy = (float) (mCenterY + minuteLength * Math.sin(Math.toRadians((mMinute * 6 + 270 + 6 * mSecond / 60.0)%360)));
        paint.setStrokeWidth(mWidth * 0.01f);
        paint.setAlpha(FULL_ALPHA);
        canvas.drawLine(mCenterX, mCenterY, minutePointx, minutePointy, paint);

        hourPointx = (float) (mCenterX + hourLength * Math.cos(Math.toRadians((mHour * 30 + 270 + 6 * mMinute / 60.0)%360)));
        hourPointy = (float) (mCenterY + hourLength * Math.sin(Math.toRadians((mHour * 30 + 270 + 6 * mMinute / 60.0)%360)));
        paint.setStrokeWidth(mWidth * 0.015f);
        canvas.drawLine(mCenterX, mCenterY, hourPointx, hourPointy, paint);
    }

    /**
     * Draw Center Dot
     *
     * @param canvas
     */
    private void drawCenter(Canvas canvas) {
        // Default Color:
        // - centerInnerColor
        // - centerOuterColor
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(degreesColor);
        canvas.drawCircle(mCenterX, mCenterY, mWidth * 0.01f, paint);


    }

    public void setShowAnalog(boolean showAnalog) {
        mShowAnalog = showAnalog;
        invalidate();
    }

    public boolean isShowAnalog() {
        return mShowAnalog;
    }

    private void getCurrentTime(){
        long time = System.currentTimeMillis();
        Calendar mCalendar = Calendar.getInstance();
        mCalendar.setTimeInMillis(time);
        mHour = mCalendar.get(Calendar.HOUR);
        mMinute = mCalendar.get(Calendar.MINUTE);
        mSecond = mCalendar.get(Calendar.SECOND);
        mAmPm = mCalendar.get(Calendar.AM_PM);
    }



}